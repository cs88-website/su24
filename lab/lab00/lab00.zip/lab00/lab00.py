"""
C88C Summer 2024:

Please credit any folks in C88C that you collaborated with,
and any online sources you searched for.
Remember, it's OK to ask for help, and to search for topics, but
you may not search for specific solutions or copy any code directly.

List Collaborators:

Credit Any Online Sources (google searches, etc):


"""


def twenty_twenty_four():
    """Come up with the most creative expression that evaluates to 2024,
    using only numbers and the +, *, and - operators.

    >>> twenty_twenty_four()
    2024
    """
    return ______
