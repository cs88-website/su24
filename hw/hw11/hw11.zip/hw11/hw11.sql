.read data.sql
-- Homework 11

-- Comment out the unfinished questions while you
-- are working so AS to avoid errors in the tests.

-- Q2
CREATE TABLE pricing as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

--Q3
CREATE TABLE long as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";
  
--Q4
CREATE TABLE smallest as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

--Q5
CREATE TABLE long_album as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

--Q6
CREATE TABLE track_count as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

--Q7
CREATE TABLE album_count as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

--Q8
CREATE TABLE busiest_artists as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";
